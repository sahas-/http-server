Intention for this server is to listen on post:8888, print a beatified JSON on the console. 
Run `./run.sh`